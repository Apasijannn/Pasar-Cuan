extends CharacterBody2D

@export var kecepatan: float = 50.0
@export var daftar_baju: Array[Texture2D] = []
@export var kecepatan_animasi: float = 0.15 

var waktu_animasi: float = 0.0

@onready var sprite = $Sprite2D

func _ready():
	if daftar_baju.size() > 0:
		var indeks_acak = randi() % daftar_baju.size()
		sprite.texture = daftar_baju[indeks_acak]
	else:
		push_error("ERROR: Daftar Baju kosong pada NPC!")

func _physics_process(_delta):
	velocity.x = kecepatan
	velocity.y = 0
	move_and_slide()

func _process(delta):
	waktu_animasi += delta
	if waktu_animasi >= kecepatan_animasi:
		waktu_animasi = 0.0 
		sprite.frame = (sprite.frame + 1) % 4

func _on_visible_on_screen_notifier_2d_screen_exited():
	queue_free()
