extends Area2D

@export var harga_barang: int = 5000
@export_range(0.0, 1.0) var peluang_beli: float = 0.4 
@export var teks_melayang_scene: PackedScene 

func _on_body_entered(body):
	if body.is_in_group("pelanggan"):
		var bos_game = get_parent()
		
		if bos_game.has_method("catat_kunjungan"):
			if randf() <= peluang_beli:
				bos_game.catat_kunjungan(true, harga_barang)
				
				if teks_melayang_scene != null:
					var teks = teks_melayang_scene.instantiate()
					teks.global_position = self.global_position 
					get_tree().current_scene.add_child(teks) 
					teks.setup("+Rp" + str(harga_barang), Color(0, 1, 0)) 
					
				body.queue_free()
