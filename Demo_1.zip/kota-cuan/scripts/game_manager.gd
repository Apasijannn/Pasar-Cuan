extends Node2D

# ==========================================
# 1. VARIABEL & PENGATURAN DASAR
# ==========================================
enum Fase {PAGI, SIANG, MALAM}
var fase_sekarang = Fase.PAGI

var hari_ke: int = 1
var opex_per_lapak: int = 2000
var bangkrut: bool = false 
var konversi = 0.0

var sel_terisi = {} 

@export var lapak_scene: PackedScene
@export var npc_scene: PackedScene 

@onready var status_label = $UILayer/StatusLabel 
@onready var spawner_timer = $NPCSpawnerTimer
@onready var layer_tanah = $LayerTanah
@onready var layer_jalan = $LayerJalan
@onready var kursor_lapak = $KursorLapak
@onready var filter_cahaya = $CanvasModulate
@onready var lampu = $PointLight2D
@onready var kamera = $Camera2D 
@onready var timer_siang = $TimerSiang
@onready var teks_hari = $UILayer/CountSign/TeksHari
@onready var teks_npc = $UILayer/CountSign/TeksPelanggan
@onready var teks_uang = $UILayer/MoneySign/TeksUang

var total_uang: int = 15000 
var pendapatan_hari_ini: int = 0
var pengunjung_hari_ini: int = 0
var pembeli_hari_ini: int = 0
var harga_bangun_lapak: int = 10000 

# ==========================================
# 2. SIKLUS UTAMA (CORE LOOP)
# ==========================================
func _ready():
	print("=== GAME KOTA CUAN DIMULAI ===")
	teks_uang.text = "Rp" + str(total_uang)
	kamera.global_position = Vector2(500, 300) 
	jalankan_fase(fase_sekarang)

func jalankan_fase(fase_baru):
	fase_sekarang = fase_baru
	
	match fase_sekarang:
		Fase.PAGI:
			filter_cahaya.color = Color(1.0, 0.95, 0.8)
			teks_hari.text = str(hari_ke)
			teks_npc.text = "0"
			status_label.text = "FASE PAGI | Klik bangun lapak"
			pendapatan_hari_ini = 0 
			pengunjung_hari_ini = 0
			pembeli_hari_ini = 0
			spawner_timer.stop()
			
		Fase.SIANG:
			filter_cahaya.color = Color(1.0, 1.0, 1.0)
			timer_siang.start()
			status_label.text = "FASE SIANG: Menunggu pelanggan..."
			spawner_timer.start()
			kursor_lapak.hide()
			
		Fase.MALAM:
			filter_cahaya.color = Color(0.2, 0.2, 0.4)
			teks_uang.text = "Rp" + str(total_uang)
			
			if pengunjung_hari_ini > 0:
				konversi = (float(pembeli_hari_ini) / float(pengunjung_hari_ini)) * 100.0
				
			var jumlah_lapak = sel_terisi.size() / 4
			var total_opex = jumlah_lapak * opex_per_lapak
			total_uang -= total_opex
			
			var laba_bersih = pendapatan_hari_ini - total_opex
			
			var laporan = "FASE MALAM (HARI KE-" + str(hari_ke) + ") - HASIL HARI INI:\n"
			laporan += "Pendapatan Kotor: Rp" + str(pendapatan_hari_ini) + "\n"
			laporan += "Biaya Operasional (" + str(jumlah_lapak) + " Lapak): -Rp" + str(total_opex) + "\n"
			laporan += "Laba Bersih Hari Ini: Rp" + str(laba_bersih) + "\n"
			laporan += "-----------------------------------\n"
			laporan += "Total Uang: Rp" + str(total_uang)

			if total_uang < 0:
				bangkrut = true
				laporan += "\n\n[ PERUSAHAAN PAILIT - GAME OVER ]"
			else:
				laporan += "\n(Tekan Spasi untuk lanjut ke Hari " + str(hari_ke + 1) + ")"
			
			status_label.text = laporan
			spawner_timer.stop()

# ==========================================
# 3. MANAJEMEN KEUANGAN & KUNJUNGAN
# ==========================================
func tambah_uang(jumlah):
	pendapatan_hari_ini += jumlah
	total_uang += jumlah
	if fase_sekarang == Fase.SIANG:
		status_label.text = "FASE SIANG: Pendapatan Sementara = Rp " + str(pendapatan_hari_ini)

func catat_kunjungan(terjual: bool, harga: int):
	# Blokir transaksi hantu saat malam hari
	if fase_sekarang != Fase.SIANG:
		return 

	pengunjung_hari_ini += 1
	teks_npc.text = str(pengunjung_hari_ini)

	if terjual:
		pembeli_hari_ini += 1
		pendapatan_hari_ini += harga
		total_uang += harga
		teks_uang.text = "Rp" + str(total_uang)

func _input(event):
	if event.is_action_pressed("ui_accept"):
		if bangkrut:
			return 
			
		if fase_sekarang == Fase.PAGI:
			jalankan_fase(Fase.SIANG)
		elif fase_sekarang == Fase.MALAM:
			hari_ke += 1 
			jalankan_fase(Fase.PAGI)

# ==========================================
# 4. LOGIKA PEMBANGUNAN & KURSOR VISUAL
# ==========================================
func _process(_delta):
	if fase_sekarang == Fase.SIANG:
		var progres = 1.0 - (timer_siang.time_left / timer_siang.wait_time)
		var warna_siang = Color(1.0, 1.0, 1.0)
		var warna_malam = Color(0.2, 0.2, 0.4)
		
		filter_cahaya.color = warna_siang.lerp(warna_malam, progres)
		status_label.text = "FASE SIANG: Sisa Waktu " + str(int(timer_siang.time_left)) + " detik"

	if fase_sekarang == Fase.PAGI:
		kursor_lapak.show()
		var posisi_mouse = get_global_mouse_position()
		
		var kordinat_utama = layer_tanah.local_to_map(posisi_mouse)
		kursor_lapak.global_position = layer_tanah.map_to_local(kordinat_utama) - Vector2(16, 16)
		
		var area_dibutuhkan = [
			kordinat_utama,                          
			kordinat_utama + Vector2i(1, 0),         
			kordinat_utama + Vector2i(0, 1),         
			kordinat_utama + Vector2i(1, 1)          
		]
		
		var bisa_dibangun = true
		for sel in area_dibutuhkan:
			var nabrak_aspal = layer_jalan.get_cell_source_id(sel) != -1
			var luar_tanah = layer_tanah.get_cell_source_id(sel) == -1
			var sudah_ada_lapak = sel_terisi.has(sel)
			
			if nabrak_aspal or luar_tanah or sudah_ada_lapak:
				bisa_dibangun = false
				break 
				
		var miskin = total_uang < harga_bangun_lapak 
		
		if not bisa_dibangun or miskin:
			kursor_lapak.color = Color(1, 0, 0, 0.5)
		else:
			kursor_lapak.color = Color(0, 1, 0, 0.5)

		if Input.is_action_just_pressed("ui_click") and bisa_dibangun and not miskin:
			bangun_lapak(kordinat_utama, area_dibutuhkan)

func bangun_lapak(kordinat_utama, area_dibutuhkan):
	if lapak_scene != null:
		var posisi_terkunci = layer_tanah.map_to_local(kordinat_utama) + Vector2(16, 16)
		var lapak_baru = lapak_scene.instantiate()
		lapak_baru.global_position = posisi_terkunci
		add_child(lapak_baru)
		
		total_uang -= harga_bangun_lapak
		teks_uang.text = "Rp" + str(total_uang)
		
		for sel in area_dibutuhkan:
			sel_terisi[sel] = true

# ==========================================
# 5. PABRIK NPC & TIMER
# ==========================================
func _on_npc_spawner_timer_timeout():
	if npc_scene != null:
		var npc_baru = npc_scene.instantiate()
		npc_baru.global_position = Vector2(-50, 270) 
		add_child(npc_baru)

func _on_timer_siang_timeout():
	if fase_sekarang == Fase.SIANG:
		jalankan_fase(Fase.MALAM)
